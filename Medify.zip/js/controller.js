angular.module('starter.controllers',  [])
.controller('TodoController', function($scope, $http){
$scope.addMed = function(){
  var name = $scope.name;
  var quantity = $scope.quantity;
  
  $http({
    url:"http://localhost/Medify/include/add.php",
    method:"POST",
    data:{
    'addname':name,
    'addquantity':quantity
    }
  })
  .then(function(response){
    console.log(response);
  })
};
  
$http({
    url:"http://localhost/medify/include/getdata.php",
    method:"GET"
  })
  .then(function(response){
    console.log(response['data']);
    $scope.medlist = response['data'];
  })  

setInterval(function(){
$http({
    url:"http://localhost/medify/include/getdata.php",
    method:"GET"
  })
  .then(function(response){
    console.log(response['data']);
    $scope.medlist = response['data'];
  })
},1000)
  

});
