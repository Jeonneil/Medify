<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Medify";
$conn =  new mysqli($servername, $username, $password, $dbname);
?>